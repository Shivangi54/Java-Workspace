import javax.persistence.*;

import com.cg.ems.Util.JPAUtil;

public class TestInheritanceDemo {

	public static void main(String[] args) {
		Emp yashi=new Emp();
		yashi.setEmpName("Yashi");
		yashi.setEmpSal(60000);
		Manager shivu=new Manager();
		shivu.setEmpName("Shivu");
		shivu.setEmpSal(5000);
		shivu.setDeptName("Java");
		
		EntityManager em=JPAUtil.getEntityManager();
        EntityTransaction tran=em.getTransaction();
        tran.begin();
        em.persist(yashi);
        em.persist(shivu);
        tran.commit();
        System.out.println("Data is inserted");
        
        Manager ee1=em.find(Manager.class, 5);
        System.out.println(ee1.getEmpName());
	}

}
