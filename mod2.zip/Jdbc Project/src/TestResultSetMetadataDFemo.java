

import java.io.IOException;
import java.sql.*;

import com.cg.errs.util.BDUtil;

public class TestResultSetMetadataDFemo {
	public static void main(String[] args) {
		
		try {
			Connection con=BDUtil.getCon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT * FROM emp1");
			
			ResultSetMetaData rsmd=rs.getMetaData();
			int colCount=rsmd.getColumnCount();
			System.out.println("No of Columns :"+colCount);
			
			for(int i=1;i<=colCount;i++)
			{
				System.out.println(i+" : Column Name : "+rsmd.getColumnName(i)+" Column Type: "+rsmd.getColumnTypeName(i));
			}
			
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
