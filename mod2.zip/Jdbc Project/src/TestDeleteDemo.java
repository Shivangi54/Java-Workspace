

import java.io.*;
import java.sql.*;
import java.util.Scanner;

import com.cg.errs.util.BDUtil;


public class TestDeleteDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter empId:");
		int eid=sc.nextInt();
		
		try {
			Connection con=BDUtil.getCon();
			
			String deleteQry="DELETE FROM  EMP1"+" WHERE emp_id=?";
			
           PreparedStatement pst=con.prepareStatement(deleteQry);
			
			pst.setInt(1, eid);
			int data=pst.executeUpdate();
			System.out.println("Data is deleted"+data);
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
