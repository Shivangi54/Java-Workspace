import java.io.*;
import java.sql.*;
import java.util.*;

import com.cg.errs.util.BDUtil;
public class TestInsertDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter empId:");
		int eid=sc.nextInt();
		System.out.println("Enter ename:");
		sc.nextLine();
		String enm=sc.nextLine();
		System.out.println("Enter Salary:");
		float esal=sc.nextFloat();
		
		try {
			Connection con=BDUtil.getCon();
			String insertQry="INSERT INTO EMP1" + "(emp_id,emp_name,emp_sal)"+"VALUES(?,?,?)";
			
			PreparedStatement pst=con.prepareStatement(insertQry);
			
			pst.setInt(1, eid);
			pst.setString(2, enm);
			pst.setFloat(3, esal);
			int data=pst.executeUpdate();
			System.out.println("Data is inserted"+data);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
