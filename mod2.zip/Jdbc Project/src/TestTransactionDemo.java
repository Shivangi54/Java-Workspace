

import java.io.IOException;
import java.sql.*;

import com.cg.errs.util.BDUtil;


public class TestTransactionDemo {

	public static void main(String[] args) {
		Connection con=null;
		try {
			 con=BDUtil.getCon();
			con.setAutoCommit(false);
			 String update1="Update emp1 set emp_name= 'Shivangi' Where emp_id=101";
			 String update2="Update emp1 set emp_sal= 3000 Where emp_id=123";
			 
			 Statement st=con.createStatement();
			 
			 st.addBatch(update1);
			 st.addBatch(update2);
			 int arr[]=st.executeBatch();
			 con.commit();
			 System.out.println("Updated Successfully");
			 
		} catch (SQLException | IOException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
			e.printStackTrace();
		}

	}

}
