
import java.io.*;
import java.sql.*;

import com.cg.errs.util.BDUtil;

public class TestProcedureDemo {

	public static void main(String[] args) {
		try
		{
		Connection con=BDUtil.getCon();
		CallableStatement cst=con.prepareCall("call pr1(?,?)");
		cst.setInt(1, 143);
		cst.registerOutParameter(2, Types.NUMERIC);
		
		ResultSet rs=cst.executeQuery();
		System.out.println("Salary is:"+cst.getInt(2));
		
		System.out.println("-----------------------");
		boolean bb=cst.execute();
		System.out.println("Salary is"+cst.getInt(2));
		
		
		
	}  catch(SQLException | IOException e)
		{
		   e.printStackTrace();
		}

}
}
