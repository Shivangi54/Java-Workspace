package com.cg.errs.util;
import java.sql.*;
import java.util.*;
import java.io.*;
public class BDUtil {
	private static String url=null;
	private static String usn=null;
	private static String pwd=null;
	private static String driver=null;
	public static Connection con=null;
	public static Connection getCon() throws SQLException, IOException
	{
		Properties myprops=getProps();
		url=myprops.getProperty("dburl");
		usn=myprops.getProperty("dbunm");
		pwd=myprops.getProperty("dbpwd");
		if(con==null)
		{
		 con=DriverManager.getConnection(url,usn,pwd);
		}
		return con;
	}
	public static Properties getProps() throws IOException
	{
		Properties dbProps=new Properties();
		FileReader fr=new FileReader("dbimport.properties");
		dbProps.load(fr);
		return dbProps;
		}
	

}
