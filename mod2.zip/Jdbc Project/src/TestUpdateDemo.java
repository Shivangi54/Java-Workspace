

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.cg.errs.util.BDUtil;

public class TestUpdateDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Salary:");
		float esal=sc.nextFloat();
          try {
			Connection con=BDUtil.getCon();
			
			String updateQry="UPDATE emp1 set emp_sal=5000 WHERE emp_sal=? ";
		    PreparedStatement pst=con.prepareStatement(updateQry);
				
				pst.setFloat(1, esal);
				int data=pst.executeUpdate();
				System.out.println("Data is updated"+data);
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
