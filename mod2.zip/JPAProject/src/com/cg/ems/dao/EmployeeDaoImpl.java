package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.*;

import com.cg.ems.Util.JPAUtil;
import com.cg.ems.dto.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
     EntityManager em=null;
     EntityTransaction entityTran=null;
     public EmployeeDaoImpl()
     {
    	 em=JPAUtil.getEntityManager();
    	 entityTran=em.getTransaction();
     }
	@Override
	public Employee addEmp(Employee emp) {
		entityTran.begin();
		em.persist(emp);            //search based on primary key
		entityTran.commit();
		return emp;
	}

	@Override
	public ArrayList<Employee> fetchAllEmp() {
		String selAllQry="SELECT emps FROM Employee emps";
		
		TypedQuery tq=em.createQuery(selAllQry,Employee.class);
		ArrayList<Employee> empList=(ArrayList)tq.getResultList();
		return empList;
	}

	@Override
	public Employee deleteEmp(int empId) {
		Employee e1=em.find(Employee.class, empId);
		entityTran.begin();
		em.remove(e1);
		entityTran.commit();
		return e1;
	}

	@Override
	public Employee getEmpbyEid(int empId) {
		Employee ee=em.find(Employee.class, empId);
		return ee;
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		Employee ee=em.find(Employee.class, empId);
		ee.setEmpName(newName);
		ee.setEmpSal(newSal);
		entityTran.begin();
		em.merge(ee);
		entityTran.commit();
		return ee;
	}
	

}
