package com.cg.ems.ui;

import java.util.*;

import com.cg.ems.dto.Employee;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class TestEmpJpaDemo {

	public static void main(String[] args) {
	EmployeeService empSer=new EmployeeServiceImpl();
	/*
	Employee e1=new Employee();
	e1.setEmpName("aaa");
	e1.setEmpSal(8000.0F);
	Employee ee1=empSer.addEmp(e1);
	System.out.println(ee1 +"\n "+ "are inserted in the table");
	*/
	//Employee ee=empSer.getEmpbyEid(555);
//	System.out.println(ee);
	/*
	System.out.println("Fetch All Records");
	
	ArrayList<Employee> eList=empSer.fetchAllEmp();
	for(Employee tempE:eList)
	{
		System.out.println(tempE.getEmpId()+"\t" +tempE.getEmpName()+"\t"+tempE.getEmpSal());
	}
	*/
//	System.out.println("Delete ");
//	Employee deleetedEmp=empSer.deleteEmp(143);
//	System.out.println("Deleted employee"+deleetedEmp);
	
	System.out.println("---Update-----");
	Employee ee=empSer.updateEmp(123, " Kartik", 30000);
	System.out.println(ee+"Is Updated");
	
	}

}
