package com.cg.lab4pr.bean;
import java.util.Random;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r=new Random();
         Person p1=new Person();
         p1.setName("Smith");
         p1.setAge(25);
         Person p2=new Person();
         p2.setName("Kathy");
         p2.setAge(45);
         CurrentAccount a=new CurrentAccount();
         a.setAccHolder(p1);
         a.setBalance(2000);
         a.setAccNum(r.nextLong());
         SavingAccount a1=new SavingAccount();
         a1.setAccHolder(p2);
         a1.setBalance(3000);
         a1.setAccNum(r.nextLong());
         a.deposit(2000);
         a1.withdraw(2000);
         System.out.println(a.toString());
         System.out.println(a1.toString());
        
         
         

}
}

