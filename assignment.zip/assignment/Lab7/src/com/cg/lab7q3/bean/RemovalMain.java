package com.cg.lab7q3.bean;
import java.util.*;
public class RemovalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Removal r=new Removal();
		List<String> l1 = new ArrayList<String>();
		Scanner s=new Scanner(System.in);
		  int n=s.nextInt();
		   for(int i=0;i<=n;i++)
		  {
			  l1.add(s.nextLine());
		  }
		List<String> l2 = new ArrayList<String>();
		 int n1=s.nextInt();
		   for(int j=0;j<=n1;j++)
		  {
			  l2.add(s.nextLine());
		  }
		l1=r.removeElements(l1,l2);
		System.out.println(l1);
		s.close();
		

	}

}
