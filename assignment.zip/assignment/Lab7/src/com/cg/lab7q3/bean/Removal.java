package com.cg.lab7q3.bean;
import java.util.*;
public class Removal {
	public List<String> removeElements(List<String> l1,List<String> l2) 
	{
		 l1.removeAll(l2); 
		  
		return l1;
		
	}

}
