package com.cg.lab7pract1.bean;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class StringOpert {
	
	public ArrayList<String> oper(String s1,String s2)
	{ 
		ArrayList<String> myList1=new ArrayList<String>();
		StringBuilder str=new StringBuilder(s1);
		int j=0,i;
		for(i=0;i<s1.length();i++)
		{
			if(i%2!=0 && j<s2.length()) {
				str.setCharAt(i,s2.charAt(j));
			j=j+2;
			if(j>=s2.length())
				j=0;
		}}
		myList1.add(str.toString());
		int endIndex=0;
		int count=0;
		while(endIndex!=-1)
		{
			endIndex=s1.indexOf(s2,endIndex);
			if(endIndex!=-1)
			{
				count++;
				endIndex+=s2.length();
			}
		}
		int strt=s1.lastIndexOf(s2);
		if(count>1)
		{
			StringBuilder str1=new StringBuilder();
			StringBuilder str2=new StringBuilder();
			str2.append(s2);
			str1=str1.reverse();
			str1.append(s1.substring(0,strt));
			str1.append(str1);
			str1.append(s1.substring(strt+s2.length()));
			myList1.add(str1.toString());
			}
		else
			myList1.add(s1+s2);
		if(count>1)
		{
			s1=s1.replaceFirst(Pattern.quote(s2),"");
			myList1.add(s1);
			
		}
		else
			myList1.add(s1);
		int n=s2.length();
		if(n%2==0)
		{
			StringBuilder sb=new StringBuilder();
			sb.append(s1);
			sb.insert(0, s2.substring(0, n/2));
			sb.append(s2.substring(n/2));
			myList1.add(sb.toString());
		}
		else
		{
			StringBuilder sb1=new StringBuilder();
			sb1.append(s1);
			sb1.insert(0, s2.substring(0, n/2+1));
			sb1.append(s2.substring(n/2+1));
			myList1.add(sb1.toString());
		}
		for(i=0;i<s1.length();i++) {
			for(j=0;j<s2.length();j++)
			{
				if(s1.charAt(i)==s2.charAt(j))
				{
					s1=s1.replace(s1.charAt(i), '*');
				}
			}
		
			}
		myList1.add(s1);
		return myList1;
	}
}

