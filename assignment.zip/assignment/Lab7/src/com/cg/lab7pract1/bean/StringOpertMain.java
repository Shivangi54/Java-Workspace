package com.cg.lab7pract1.bean;
import java.util.*;
public class StringOpertMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc=new Scanner(System.in);
      String s1=sc.nextLine();
      String s2=sc.nextLine();
      StringOpert s=new StringOpert();
      ArrayList<String> myList1=new ArrayList<String>();
      myList1=s.oper(s1,s2);
      System.out.println(myList1);
      sc.close();
	}

}
