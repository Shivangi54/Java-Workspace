package com.cg.lab7pract.bean;
import java.util.*;
public class SortingArray {
	
	public Object[] getSorted(int[]arr) 
	{
		StringBuilder in = new StringBuilder();  
		for(int j=0;j<arr.length;j++)
		{
        in.append(arr[j]);
        in.append(" ");
		}
        in = in.reverse(); 
        String[] str=in.toString().split("/n");
        ArrayList<String> c = new ArrayList<String>(Arrays.asList(str)); 
        Collections.sort(c); 
        Object[] o=c.toArray();
        return o;
      }
}
	




