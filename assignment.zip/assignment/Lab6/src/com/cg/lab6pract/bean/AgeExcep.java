package com.cg.lab6pract.bean;
import java.lang.Exception;

class AgeException extends Exception {
    private int a;
    AgeException(int age) {
        a = age;
       
     }
	@Override
	public String toString() {
		return "AgeException [a=" + a + "]";
	}
    
}
public class AgeExcep {
		 static void getDetails(int a)throws AgeException
		 {
			 System.out.println("called getDetails("+a+")");
			 if (a<16)
				throw new AgeException(a);
		     System.out.println("Age is above 16");
		 }
			 
		
public static void main(String arg[]) {
	try {
		getDetails(23);
		getDetails(12);
	} catch (AgeException ag) {
		System.out.println("Age is less than 16"+ag);
    }
}  
}


