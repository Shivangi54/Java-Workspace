package com.cg.lab6pract.bean;
import java.lang.Exception;

class PersonException extends Exception {
    private String firstname,lastname;
    PersonException(String f,String l) {
        firstname = f;
        lastname=l;
     }
	@Override
	public String toString() {
		return "PersonException [firstname=" + "is blank" + ", lastname=" + "is blank" + "]";
	}
}
public class UserExcep {
	 static void getDetails(String f,String l)throws PersonException
	 {
		 System.out.println("called getDetails("+f+l+")");
		 if (f==" " && l==" ")
			throw new PersonException(f,l);
	     System.out.println("Firstname and Lastname is not Blank");
	 }
	 public static void main(String[] args) {
			// TODO Auto-generated method stub
			try
			{
				getDetails("Shivangi", "Tripathi");
				getDetails(" "," ");
				}
			catch(PersonException p)
			{
				System.out.println("Firstname and Lastname is blank" +p);
			}
			

		}
		 
			  
		  
		 
	 }
	

    
	
     
