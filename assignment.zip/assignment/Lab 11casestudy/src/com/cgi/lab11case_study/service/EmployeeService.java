package com.cgi.lab11case_study.service;
import java.util.*;
import java.util.stream.Collectors;
import com.cgi.lab11case_study.bean.*;
import com.cgi.lab11case_study.util.*;
public class EmployeeService {
	public static void main(String args[]) {
     System.out.println("Sum of salary of all the employees");
     int sum=0;
     List<Employee> list=EmployeeRepository.getEmployeeList();
     for(int i=0;i<EmployeeRepository.getEmployeeList().size();i++) {
    	 Employee emp=list.get(i);
    	 sum+=emp.getSalary();
     }
     System.out.println(sum);
     System.out.println("Department names and count of employees in each department");
     
     Map<Department,List<Employee>> employeeCount = EmployeeRepository.getEmployeeList().stream().distinct().collect(Collectors.groupingBy((employee)->employee.getDepartment()));
		for(Department dept:employeeCount.keySet()) {
			long l=employeeCount.values().stream().distinct().collect(Collectors.counting());
			  System.out.println(dept.getDepartmentName()+":"+l);
		}
	}
}
