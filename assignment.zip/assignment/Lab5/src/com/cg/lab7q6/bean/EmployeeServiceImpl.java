package com.cg.lab7q6.bean;
import java.util.HashMap;

import com.cg.eis.bean.*;
public class EmployeeServiceImpl {
	
	HashMap<String,Employee> list = new HashMap<String,Employee>();
	public void addEmployee(Employee emp)
	{
	  emp.getId();
	  emp.getName();
	  emp.getSalary();
	  emp.getDesignation();
	}
	public boolean deleteEmployee(int id)
	{
		return false;
	  
	}

}
