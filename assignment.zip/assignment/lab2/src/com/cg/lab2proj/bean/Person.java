package com.cg.lab2proj.bean;

public class Person {

	private String firstname;
	private String lastname;
	private Gender gender;
	private String phno;
	
	
	
	public String getPhno() {
		return phno;
	}


	public void setPhno(String phno) {
		this.phno = phno;
	}

/*
	@Override
	public String toString() {
		return "First name:"+firstname+"\nLast name:"+lastname+"\nGender:"+gender;
	}

*/
	public Person() {
		super();
	}


	public Person(String firstname, String lastname, Gender gender,String phno) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.phno=phno;
	}


	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	public void displaydetails()
	{
		System.out.println("First Name:"+ getFirstname());
		System.out.println("Last Name:"+ getLastname());
		System.out.println("Gender:"+ getGender());
		System.out.println("Phone Number:"+getPhno());
	}
}
