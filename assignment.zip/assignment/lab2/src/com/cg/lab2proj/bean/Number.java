package com.cg.lab2proj.bean;

public class Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          
          int n=Integer.parseInt(args[0]);
          if(n>0)
        	  System.out.println("Positive");
          else
        	  System.out.println("Negative");
	}

}
