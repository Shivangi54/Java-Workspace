package com.cg.lab2proj.bean;

public class PersonMain{
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person p= new Person("Shivu","Trip",Gender.F,"7895167416");
		/*
		System.out.println("First Name:"+ p.getFirstname());
		System.out.println("Last Name:"+ p.getLastname());
		System.out.println("Gender:"+ p.getGender());
		
		
		System.out.println(p);
      */
		
		p.displaydetails();
		
	}

}
