package com.cg.lab2proj.bean;

public enum Gender {
	M,F;

}
