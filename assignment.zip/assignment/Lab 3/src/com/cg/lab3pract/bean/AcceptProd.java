package com.cg.lab3pract.bean;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class AcceptProd {
	
	public void accept(LocalDate p,int m,int y)
	{
		System.out.println("Purchase date :"+ p);
		LocalDate d1=p.plusMonths(m);
		LocalDate d3=d1.plusYears(y);
		System.out.println("Expiry Date :"+ d3);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AcceptProd a=new AcceptProd();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter date of product purchase");
		String t=scan.nextLine();
		System.out.println("Enter warrantee of the product in mm/yyyy");
		int m=scan.nextInt();
		int y=scan.nextInt();
		DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate l=LocalDate.parse(t, f);
		a.accept(l, m,y);
		scan.close();
		}
}
