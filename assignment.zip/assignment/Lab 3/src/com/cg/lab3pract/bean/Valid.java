package com.cg.lab3pract.bean;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
public class Valid {
	
	public boolean Validation(String u)
	{
		String m="_job$";
		Pattern p=Pattern.compile(m);
		Matcher matcher = p.matcher(u);
		if(matcher.find() && (u.length()-4>=8))
			return true;
		else
				return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean r;
		Valid v= new Valid();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Username");
		String s=scan.nextLine();
		r=v.Validation(s);
		if(r)
		System.out.println("true");
		else
			System.out.println("false");
		scan.close();
		
	}

}
