package com.cg.lab3pract.bean;


import java.util.Scanner;

public class String1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String1 s1=new String1();
        System.out.println("Enter String");
        String str=s.nextLine();
        System.out.println("Enter User's Choice");
        System.out.println("A.Add String to itself");
        System.out.println("B.Replace odd position with #");
        System.out.println("C.Remove duplicate characters in the string");
        System.out.println("D.Change odd characters to upperacse");
        char ch=s.next().charAt(0);
        s1.cal(str, ch);
        s.close();
	}
	
	public void cal(String str,int choice)
	{
		switch(choice)
		{
		case 'A':System.out.println(str+str);
		         break;
		case 'B':for(int i=0;i<str.length();i++) {
			      if(i%2!=0)
			    	  str=str.substring(0, i-1)+'#'+str.substring(i,str.length());
		}
		System.out.println(str);
		break;
		case 'C':String st="";
		         for(int i=0;i<str.length();i++)
		         {
		        	 if(!str.contains(String.valueOf(str.charAt(i))))
		        			 st=st+String.valueOf(str.charAt(i));
		         }
		         System.out.println(st);
		         break;
		case 'D': for(int i=0;i<str.length();i++) {
			       char c=str.charAt(i);
			       if(i%2!=0)
			    	   System.out.print(Character.toLowerCase(c));
			       else
			    	   System.out.print(Character.toUpperCase(c));
			       }
		           break;
		           default:System.out.println("Incoorect ");
			
		
		}
	}

}
