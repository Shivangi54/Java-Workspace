package com.cg.lab3pract.bean;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Accept2 {
	
	public void accept2(LocalDate s,LocalDate t)
	{
		Period period = s.until(t);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
        Accept2 a= new Accept2();
        Scanner s =new Scanner(System.in);
		String st=s.nextLine();
		String t=s.nextLine();
		DateTimeFormatter f= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dt = LocalDate.parse(st,f);
		LocalDate d = LocalDate.parse(t,f);
		a.accept2(dt,d);
		s.close();
	}

}
