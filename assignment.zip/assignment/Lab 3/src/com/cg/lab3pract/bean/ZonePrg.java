package com.cg.lab3pract.bean;
import java.time.*;
import java.util.Scanner;
public class ZonePrg {
	
	public  void Timeacceptof(String id)
	{ 
		if(id.equals(ZoneId.of(id).toString()))
		System.out.println(ZonedDateTime.now(ZoneId.of(id)));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ZonePrg z= new ZonePrg(); 
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter zone in a/b form");
		String s=scan.nextLine();
		z.Timeacceptof(s);
		scan.close();

	}

}
