package com.cg.lab3pract.bean;
import java.lang.Character;
import java.util.Scanner;

public class String2 {
	
	public boolean accept(String s)
	{
		boolean say=true;
		 for(int i=0;i<s.length();i++) {
			char a = s.charAt(i);
		for(int j=i+1;j<s.length();j++)
		{
			char b = s.charAt(j);
		 if(Character.valueOf(a).compareTo(Character.valueOf(b))>0)
		 {
			 say=false;
		 }
			
		}}
		 return say;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String p=s.nextLine();
		String2 a=new String2();
		boolean say=a.accept(p);
		if(say)
			System.out.println("Positive String");
		else
			System.out.println("Not a Positive String");
		s.close();

	}

}
