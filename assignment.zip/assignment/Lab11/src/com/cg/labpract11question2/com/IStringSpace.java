package com.cg.labpract11question2.com;

@FunctionalInterface
public interface IStringSpace {
	public void space(String c);
	

}