package com.capgemini.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.capgemini.beans.*;
import com.capgemini.dao.WalletDao;
import com.capgemini.dao.WalletDaoImpl;
import com.capgemini.exception.WalletException;
public class Testing {
   WalletDao walletdao;

   @Before
	public void setTest()
	{
	walletdao=new WalletDaoImpl();
	
	}
	@Test
	public void WhetherValidMobileNumber() throws WalletException
	{
		assertEquals(false, WalletDaoImpl.validateMobileNo("7895"));
		assertEquals(true, WalletDaoImpl.validateMobileNo("7895167416"));
	}
	@Test
	public void WhetherValidName() throws WalletException
	{
		assertEquals(false, WalletDaoImpl.isValidName("ab"));
		assertEquals(true, WalletDaoImpl.isValidName("Shivangi Tripathi"));
	}
	@Test
	public void WhetherValidBalance() throws WalletException
	{
		assertEquals(false, WalletDaoImpl.isValidBalance(-2500));
		assertEquals(true, WalletDaoImpl.isValidBalance(2500));
	}
	@Test
	public void WhenDepositMoney()throws WalletException
	{
		Customer custom;
		boolean flag;
		custom=walletdao.depositAmount("7895167416", 500);
		if(custom==null)
			flag=false;
		else
			flag=true;
		assertTrue(flag);
	    }
	@Test
	public void WhenWithdrawMoney()throws WalletException
	{
		Customer custom;
		boolean flag;
		custom=walletdao.depositAmount("7895167416", 1500);
		if(custom==null)
			flag=false;
		else
			flag=true;
		assertTrue(flag);
	    }
	@Test
	public void WhenFundTransfer()throws WalletException
	{
		walletdao.fundTransfer("7895167416","9450345042", 1000);
    }
	@Test
	public void WhenCreateAccount()throws WalletException
	{
		walletdao.createAccount("7895167416");
		walletdao.createAccount("8394839301");
	}
	@Test
	public void ShowBalance()throws WalletException
	{
		boolean flag;
		double balance;
		balance=walletdao.showBalance("7895167416");
		if(balance==0)
			flag=false;
		else
			flag=true;
		assertTrue(flag);
		double bal=walletdao.showBalance("9999");
		if(bal==0)
			flag=false;
		else
			flag=true;
		assertFalse(flag);
	}
	
		
	
	@After
	public void setFreeTest()
	{
		walletdao=null;
	}
}
