package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;
import com.capgemini.exception.WalletException;
import com.capgemini.util.CollectionUtil;

public class WalletDaoImpl implements WalletDao {
	
	Customer custom=new Customer();
	Wallet wallet=new Wallet();
	EntityManager em=null;
    EntityTransaction entityTransaction=null;
    ArrayList<Customer> customList=new ArrayList<Customer>();
	Scanner scanner=new Scanner(System.in);
	public WalletDaoImpl() {
    	em=CollectionUtil.getEntityManager();
    	entityTransaction=em.getTransaction();
    }
	@Override
	public ArrayList<Customer> createAccount(String mobileNo) throws WalletException {
		if(em.find(Customer.class, mobileNo)!=null) {
			System.out.println("Account already Exists!");
		}
		else {
			custom.setMobileno(mobileNo);
			System.out.println("Enter Your Full Name");
			custom.setName(scanner.nextLine());
			while(true) {
	  	          if(WalletDaoImpl.isValidName(custom.getName())) {
	  	        	break;
	  	          }
	  	          else {
	  	        	System.err.println(" Customer Name Should Be In Alphabets and minimum 3 characters long ! \n");
	  	        	  custom.setName(scanner.nextLine());
	  	        	  
	  	          }
	  	    }
			System.out.println("Enter wallet Details:");
			System.out.println("Enter balance");
			wallet.setBalance(scanner.nextDouble());
			while(true) {
			if(WalletDaoImpl.isValidBalance(wallet.getBalance())) {
				custom.setWallet(wallet);
				break;
			}
			else {
				System.err.println("Customer's Account Balance should be greater than 0 and less than 10000");
				wallet.setBalance(scanner.nextDouble());
			}
			}
			entityTransaction.begin();
			em.persist(custom);
			entityTransaction.commit();
			customList.add(custom);
		}
		return customList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public double showBalance(String mobileNo) throws WalletException {
		
		if(em.find(Customer.class, mobileNo)!=null) {
			Query query=em.createQuery("SELECT customer from Customer customer where customer.mobileNo='"+mobileNo+"'");
			customList=(ArrayList<Customer>)query.getResultList();
			return customList.get(0).getWallet().getBalance();
		    
		}
		else 
			return 0;
		
		
	}

	@Override
	public void fundTransfer(String sourceMobileNo, String targetMobileNo, double amount)
			throws WalletException {
		WalletDaoImpl walletDaoImpl=new WalletDaoImpl();
		Customer source=walletDaoImpl.withdrawAmount(sourceMobileNo, amount);
		customList.add(source);
		System.out.println(source);
		Customer target=walletDaoImpl.depositAmount(targetMobileNo, amount);
		System.out.println(target);
		customList.add(target);
		
	}
	
	@Override
	public Customer depositAmount(String mobileNo, double amount) throws WalletException {
		
		if(em.find(Customer.class, mobileNo)!=null) {
			/*Query query1=em.createQuery("UPDATE Customer as customer SET customer.balance=customer.balance+"+amount+" WHERE customer.balance=customer.balance");
			Query query2=em.createQuery("UPDATE Wallet as wallet SET wallet.balance=wallet.balance+"+amount+" WHERE wallet.balance=wallet.balance");
			int val1=query1.executeUpdate();
			int val2=query2.executeUpdate();*/
			custom=em.find(Customer.class, mobileNo);
			wallet=custom.getWallet();
			wallet.setBalance(wallet.getBalance()+amount);
			custom.setWallet(wallet);
			return custom;
		}
		else
			return null;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, double amount) throws WalletException {
		if(em.find(Customer.class, mobileNo)!=null) {
			custom=em.find(Customer.class, mobileNo);
			wallet=custom.getWallet();
			wallet.setBalance(wallet.getBalance()-amount);
			custom.setWallet(wallet);
			return custom;
		}
		else
			return null;
}
	public static boolean validateMobileNo(String mobileNo) {
		Pattern phonePattern=Pattern.compile("^[7-9]{1}[0-9]{9}$");
			Matcher phoneMatcher=phonePattern.matcher(mobileNo);
			return phoneMatcher.matches();
	}
	public static boolean isValidName(String Name){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}\\s[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(Name);
			return nameMatcher.matches();
		}
	public static boolean isValidBalance(double balance) {
		if(balance>0 && balance<10000)
			return true;
		else
			return false;
	}
}