package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.beans.Customer;
import com.capgemini.dao.WalletDao;
import com.capgemini.dao.WalletDaoImpl;
import com.capgemini.exception.WalletException;

public class WalletServiceImpl implements WalletService {

	private WalletDao walletDao;

	public WalletServiceImpl() {
		
		walletDao=new WalletDaoImpl();
	}



	//CREATE ACCOUNT
	@Override
	public ArrayList<Customer> createAccount(String mobileNo) throws WalletException
	{
		ArrayList<Customer> custom = walletDao.createAccount(mobileNo);
		return custom;
	}


	//SHOW BALANCE
	@Override
	public double showBalance(String mobileNo) throws WalletException
	{

		double balance=walletDao.showBalance(mobileNo);
		return balance;
	}



	//DEPOSIT AMOUNT
	@Override
	public Customer depositAmount(String mobileNo, double amount) throws WalletException
	{
		Customer customer= walletDao.depositAmount(mobileNo, amount);
		return customer;
	}




	//WITHDRAW AMOUNT
	@Override
	public Customer withdrawAmount(String mobileNo, double amount) throws WalletException
	{
		Customer customer=walletDao.withdrawAmount(mobileNo, amount);
		return customer;
	}


	//FUND TRANSFER
		@Override
		public void fundTransfer(String sourceMobileNo, String targetMobileNo, double amount) throws WalletException
		{

			walletDao.fundTransfer(sourceMobileNo, targetMobileNo, amount);
			
		}

}