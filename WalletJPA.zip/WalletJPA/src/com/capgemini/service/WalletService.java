package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.beans.Customer;
import com.capgemini.exception.WalletException;

public interface WalletService 
{
	public ArrayList<Customer> createAccount(String mobileNo) 
			throws WalletException;

	public double showBalance(String mobileNo) 
			throws WalletException;

	public void fundTransfer(String sourceMobileNo, String targetMobileNo, double amount) 
			throws WalletException;

	public Customer depositAmount(String mobileNo, double amount) 
			throws WalletException;

	public Customer withdrawAmount(String mobileNo, double amount) 
			throws WalletException;



}
