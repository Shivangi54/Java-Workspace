package com.capgemini.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Wallet {
	@Id
	@Column(name = "balance" ,length=10)
	private double balance;

	public Wallet() {
		super();
		
	}

	public Wallet(int i) {
		super();
		this.balance = i;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet[balance: " + balance + "]";
	}

}
