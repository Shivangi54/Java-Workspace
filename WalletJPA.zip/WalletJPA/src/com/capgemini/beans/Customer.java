package com.capgemini.beans;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Customer 
{
	@Column(name = "name", length=30)
	private String name;
	@Id
	@Column(name = "mobile_no", length=10)
	private String mobileNo;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="balance")
	private Wallet wallet;


	public Customer() {
		super();
		
	}
	public Customer(String name, String mobileno, Wallet wallet) {
		super();
		this.name = name;
		this.mobileNo = mobileno;
		this.wallet = wallet;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileno() {
		return mobileNo;
	}
	public void setMobileno(String mobileno) {
		this.mobileNo = mobileno;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	@Override
	public String toString()
	{
		return "Customer[name: "+name+" MobileNumber: "+mobileNo+" Wallet: "+wallet+"]";
	}



}