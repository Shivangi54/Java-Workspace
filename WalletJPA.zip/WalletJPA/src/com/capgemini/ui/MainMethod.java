package com.capgemini.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.beans.Customer;
import com.capgemini.dao.WalletDaoImpl;
import com.capgemini.exception.WalletException;
import com.capgemini.service.WalletService;
import com.capgemini.service.WalletServiceImpl;

public class MainMethod 
{

	public static void main(String[] args) throws WalletException 
	{
		String mobileNo;
		int choice;
		WalletService walletServiceImpl=new WalletServiceImpl();
		while(true) {
		      System.out.println("Enter your choice: ");
	          System.out.println("1- Create Account");
	          System.out.println("2- Show Balance");
	          System.out.println("3- Fund Transfer");
	          System.out.println("4- Deposit Money");
	          System.out.println("5- Withdraw Money");
	          System.out.println("6- Exit");
	          Scanner scan=new Scanner(System.in);
	          try {
	              choice=scan.nextInt();
     
                switch(choice) {
                case 1: System.out.println("Enter your mobile no");
                scan.nextLine();
                mobileNo=scan.nextLine();
                		while (true) {
    						if (WalletDaoImpl.validateMobileNo(mobileNo)) {
    							break;
    						} else {
    							System.err.println("Please enter valid mobile no only, try again");
    							mobileNo = scan.nextLine();
    						}
    					}
                        try {
                       ArrayList<Customer> customer=walletServiceImpl.createAccount(mobileNo);
	               			System.out.println(customer);
               		}
                       catch(Exception mpe) {
                        	throw new WalletException("Error in inserting details! Try Again!");
                        }
                        break;
                case 2: System.out.println("Enter your mobile no");
                		scan.nextLine();
                        mobileNo=scan.nextLine();
                        while(true) {
                        	if(WalletDaoImpl.validateMobileNo(mobileNo)) {
                        		break;
                        	} else {
                        		System.err.println("Please enter valid mobileno! Try Again!");
                        		mobileNo=scan.nextLine();
                        	}
                        }
                        try {
                        	double balance=walletServiceImpl.showBalance(mobileNo);
                        	System.out.println("Your balance is : "+balance);
                        }catch(Exception e) {
                        	throw new WalletException("Error in showing balance! Try Again Later!");
                        }
                        break;
                case 3: System.out.println("Enter your mobile no");
                 		scan.nextLine();
                 		mobileNo=scan.nextLine();
                 		System.out.println("Enter the mobile no of another user");
                 		String mobileNo1=scan.nextLine();
                 		System.out.println("Enter the amount to be transferred!");
                 		double amtTrans=scan.nextDouble();
                 		while(true) {
                        	if(WalletDaoImpl.validateMobileNo(mobileNo) && WalletDaoImpl.validateMobileNo(mobileNo1)) {
                        		break;
                        	} else {
                        		System.err.println("Please enter valid mobileno! Try Again!");
                        		mobileNo=scan.nextLine();
                        	}
                        }
                        try {
                        	walletServiceImpl.fundTransfer(mobileNo, mobileNo1, amtTrans);
                  
                        }catch(Exception e) {
                        	throw new WalletException("Error in showing balance! Try Again Later!");
                        }
                        break;
                case 4: System.out.println("Enter your mobile no");
		        		scan.nextLine();
		                mobileNo=scan.nextLine();
		                System.out.println("Enter the amount you want to deposit");
		                double amount=scan.nextDouble();
		                while(true) {
		                	if(WalletDaoImpl.validateMobileNo(mobileNo)) {
		                		break;
		                	} else {
		                		System.err.println("Please enter valid mobileno! Try Again!");
		                		mobileNo=scan.nextLine();
		                	}
		                }
		                try {
		                	Customer customer=walletServiceImpl.depositAmount(mobileNo, amount);
		                	System.out.println(customer);
		                }catch(Exception e) {
		                	throw new WalletException("Error in depositing balance! Try Again Later!");
		                }
		                break;
                case 5: System.out.println("Enter your mobile no");
		        		scan.nextLine();
		                mobileNo=scan.nextLine();
		                System.out.println("Enter the amount you want to withdraw");
		                double amt=scan.nextDouble();
		                while(true) {
		                	if(WalletDaoImpl.validateMobileNo(mobileNo)) {
		                		break;
		                	} else {
		                		System.err.println("Please enter valid mobileno! Try Again!");
		                		mobileNo=scan.nextLine();
		                	}
		                }
		                try {
		                	Customer customer=walletServiceImpl.withdrawAmount(mobileNo, amt);
		                	System.out.println(customer);
		                }catch(Exception e) {
		                	throw new WalletException("Error in withdrawing balance! Try Again Later!");
		                }
		                break;
		                }
	          }catch(InputMismatchException e) {
	        	  scan.nextLine();
					System.err.println("Please enter a valid value, try again");
	          }
	          
		}
	}
}
