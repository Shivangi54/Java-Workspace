package com.cg.walletapp.repository;

import com.cg.walletapp.bean.Customer;

public interface WalletRepo 
{
	public boolean save(Customer customer);
	public Customer findOne(String mobileNo);

}
