package com.cg.lab7pr.bean;

public class NumFactMain {
	public static void main(String []args)
	{
		NumberThread nt=new NumberThread();
		nt.start();
		FactorialThread f=new FactorialThread();
		f.start();
	}

}
