package com.cg.lab7pr.bean;

public class CopyDataThread {

}
