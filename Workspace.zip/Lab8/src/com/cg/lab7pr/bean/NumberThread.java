package com.cg.lab7pr.bean;
import java.util.*;
public class NumberThread extends Thread {
	public void run()
	{
		Random r=new Random();
		for(int i=1;i<=10;i++)
		{
		int n=r.nextInt();
		System.out.println("Number is:"+n);
		
		}

}
}
