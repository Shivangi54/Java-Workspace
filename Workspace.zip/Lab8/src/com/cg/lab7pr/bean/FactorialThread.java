package com.cg.lab7pr.bean;

public class FactorialThread extends Thread {
     public void run()
	{  
		int fact=1; 
		for(int i=1;i<;i++){    
	      fact=fact*i;    
	}
		System.out.println("Factorial is:"+fact);

}}
