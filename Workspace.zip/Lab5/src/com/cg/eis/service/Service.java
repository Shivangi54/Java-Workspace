package com.cg.eis.service;
import java.util.*;
import com.cg.eis.exception.lab6.*;
import com.cg.eis.bean.Employee;
public class Service implements EmployeeService{
	Employee e1;
	@Override
	public void getDetails()
	{
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		String desi=sc.next();
		int id=sc.nextInt();
		double sal=sc.nextDouble();
		try
		{
			if(sal<3000)
				throw new EmployeeException(sal);
		}
		catch(EmployeeException e)
		{
			System.out.println(e);
		}
		e1=new Employee(id,name,sal,desi);
		sc.close();
	}
	@Override
	public String findInsuranceScheme()
	{
		if((e1.getSalary())>5000 && (e1.getSalary())<20000 && e1.getDesignation().equals("System Associate"))
			return "Scheme C";
		else if((e1.getSalary())>=20000 && (e1.getSalary())<40000 && e1.getDesignation().equals("Programmer"))
			return "Scheme B";
		else if((e1.getSalary())>=40000 &&  e1.getDesignation().equals("Manager"))
			return "Scheme A";
		else if((e1.getSalary())<5000 &&  e1.getDesignation().equals("Clerk"))
			return "No Scheme";
		return "null";
	}
	@Override
	public void DisplayDetails()
	{
		System.out.println("Id is :"+e1.getId()+" Name is :"+e1.getName()+" Salary is: "+e1.getSalary()+" Designation is: "+e1.getDesignation()+"Insurance Scheme :"+findInsuranceScheme());
		
		
	}

	

}
