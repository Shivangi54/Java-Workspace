package com.cg.mobilepurchase.repository;

public interface MobileRepositoryInterface {
	public void insertDetails(int mobileid);
	public void updateDetails(int mobileid);
	public void viewMobileDetail();
	public void deleteMobileDetail(int mobileid);
	public  void searchMobile(int low,int high);

}
