package com.cg.mobilepurchase.repository;
import java.util.*;
import com.cg.mobilepurchase.bean.MobileDetails;
import com.cg.mobilepurchase.bean.PurchaseDetails;
//import com.cg.mobilepurchase.repository.MobileRepository;
import com.cg.mobilepurchase.util.MobilePurchaseStore;
public class MobileRepository implements MobileRepositoryInterface{
	
		MobilePurchaseStore store=new MobilePurchaseStore();
	   MobileDetails mobiledetail=new MobileDetails();
	   Map<Integer,PurchaseDetails> purchase =new  HashMap<Integer,PurchaseDetails>();
	  // Map<Integer,MobileDetails> mobile=new HashMap<Integer,MobileDetails>() ;


	  public  void insertDetails(int mobileid)
		{
			PurchaseDetails purchasedetail=new PurchaseDetails();
			Scanner scanner=new Scanner(System.in);
	        purchasedetail.setCname(scanner.nextLine());
			purchasedetail.setMailId(scanner.nextLine());
			purchasedetail.setPurchasedate(scanner.nextLine());
			purchasedetail.setPhnNo(scanner.nextLine());
			purchasedetail.setPurchaseId(mobileid);
			
			purchase.put(mobileid, purchasedetail);
			Iterator<Integer> iterator=purchase.keySet().iterator();
			while(iterator.hasNext())
			{
				Integer key=iterator.next();
				System.out.println(key+":"+purchase.get(key));
			}
			
			scanner.close();
		}
	  public void updateDetails(int mobileid)
	  {
		  
		  
	  }
		public  void viewMobileDetail()
		{
			Map<Integer,MobileDetails> mobile1=store.prepareMobileList();
					
			
			 Iterator<Integer> iterator=mobile1.keySet().iterator();
				while(iterator.hasNext())
				{
					Integer key=iterator.next();
					System.out.println(key+":"+mobile1.get(key));
				}
			
		}
		public  void deleteMobileDetail(int mobileid)
		{
			Map<Integer,MobileDetails> mobile=store.prepareMobileList();
			
			if(mobile.containsKey(mobileid))
			{
				mobile.remove(mobileid);
				System.out.println("Mobileid deleted");
			}
			else
				System.out.println("Mobile id not found");
		}
			
		public  void searchMobile(int low,int high)
		{
			Map<Integer,MobileDetails> mobile=store.prepareMobileList();
			Iterator<Integer> iterator1=mobile.keySet().iterator();
			while(iterator1.hasNext())
			{
				Integer key1=iterator1.next();
				MobileDetails m=mobile.get(key1);
				if(m.getMobilr_price()>=low &&m.getMobilr_price()<=high)
						{
					   System.out.println(key1+":"+mobile.get(key1));
						}
			
			}
		
			
		}
		
		

	}



