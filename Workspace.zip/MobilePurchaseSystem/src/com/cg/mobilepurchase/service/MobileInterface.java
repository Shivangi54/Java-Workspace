package com.cg.mobilepurchase.service;

public interface MobileInterface {
	public void insertDetails(int mobileid);
	public void viewMobileDetail();
	public void deleteMobileDetail(int mobileid);
	public  void searchMobile(int low,int high);

}
