package com.cg.mobilepurchase.bean;

public class MobileDetails {
		private int mobile_id;
		private String mobile_name;
		private float mobile_price;
		private int mobile_quantity;
		public MobileDetails() {
			super();
		}
		public MobileDetails( String mobile_name, int mobilr_price, int mobile_quantity) {
			super();
			this.mobile_name = mobile_name;
			this.mobile_price = mobilr_price;
			this.mobile_quantity = mobile_quantity;
		}
		public int getMobile_id() {
			return mobile_id;
		}
		public void setMobile_id(int mobile_id) {
			this.mobile_id = mobile_id;
		}
		public String getMobile_name() {
			return mobile_name;
		}
		public void setMobile_name(String mobile_name) {
			this.mobile_name = mobile_name;
		}
		public float getMobilr_price() {
			return mobile_price;
		}
		public void setMobilr_price(float mobilr_price) {
			this.mobile_price = mobilr_price;
		}
		public int getMobile_quantity() {
			return mobile_quantity;
		}
		public void setMobile_quantity(int mobile_quantity) {
			this.mobile_quantity = mobile_quantity;
		}
		@Override
		public String toString() {
			return "MobileDetails [" +"mobile_name=" + mobile_name + ", mobile_price="
					+ mobile_price + ", mobile_quantity=" + mobile_quantity + "]";
		}
		
		
		

	}



