package com.cg.mobilepurchase.bean;
import java.time.*;
import java.time.format.DateTimeFormatter;



public class PurchaseDetails {
	private int purchaseId;
	private String cname;
	private String mailId;
	private String phnNo;
	private LocalDate purchasedate;
	//private MobileDetails mobileid;
	public PurchaseDetails() {
		super();
	}
	public PurchaseDetails(int purchaseId, String cname, String mailId, String phnNo,LocalDate purchasedate) {
		super();
		this.purchaseId = purchaseId;
		this.cname = cname;
		this.mailId = mailId;
		this.phnNo = phnNo;
		this.purchasedate = purchasedate;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhnNo() {
		return phnNo;
	}
	public void setPhnNo(String phnNo) {
		this.phnNo = phnNo;
	}
	public LocalDate getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(String purchasedate) {
	 DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate input=LocalDate.parse(purchasedate, formatter);
		this.purchasedate = input;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", cname=" + cname + ", mailId=" + mailId + ", phnNo="
				+ phnNo + ", purchasedate=" + purchasedate + "]";
	}
	
	
	
	

}
