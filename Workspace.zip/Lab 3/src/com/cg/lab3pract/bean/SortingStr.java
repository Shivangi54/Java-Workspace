package com.cg.lab3pract.bean;

import java.util.Arrays;
import java.util.Scanner;

public class SortingStr {

	 public void sortof(String s[])
	 {
		 Arrays.sort(s);
		 for(int i=0;i<5;i++)
		 {
			 int n=s[i].length();
			 if(n%2==0)
			 System.out.println(s[i].substring(0,n/2).toUpperCase()+s[i].substring(n/2).toLowerCase());
				 else
					 System.out.println(s[i].substring(0,n/2+1).toUpperCase()+s[i].substring(n/2+1).toLowerCase());
			 
		 }
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortingStr s=new SortingStr();
		Scanner scan=new Scanner(System.in);
		String[] str=new String[5];
		for(int i=0;i<5;i++)
		{
			 str[i]=scan.nextLine();
		}
		s.sortof(str);
		scan.close();
	}

}
