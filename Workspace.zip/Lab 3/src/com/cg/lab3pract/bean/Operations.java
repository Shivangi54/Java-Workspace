package com.cg.lab3pract.bean;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Operations {
	
	public  void accept(LocalDate date)
	{

	      LocalDate currentDate = LocalDate.now();
	     
	      Period period = date.until(currentDate);
			
			System.out.println("Days:"+ period.getDays());
			System.out.println("Months:"+period.getMonths());
			System.out.println("Years:"+ period.getYears());
	}
	public static void main(String args[])
	{
		Operations op=new Operations();
		Scanner s =new Scanner(System.in);
		String st=s.nextLine();
		DateTimeFormatter f= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dt = LocalDate.parse(st,f);
		op.accept(dt);
		s.close();
	}
	

}

	
