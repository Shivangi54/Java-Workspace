package com.cg.lab7q5.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class Product {
	public void storeProd(ArrayList<String> l)
	{
		Collections.sort(l);
		for(String str:l)
		{
			System.out.println(str);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Product p=new Product();
		  ArrayList<String> l = new ArrayList<String>(); 
		  Scanner s=new Scanner(System.in);
		  int n=s.nextInt();
		   for(int i=0;i<=n;i++)
		  {
			  l.add(s.nextLine());
		  }
		  p.storeProd(l);
		  s.close();

	}

}
