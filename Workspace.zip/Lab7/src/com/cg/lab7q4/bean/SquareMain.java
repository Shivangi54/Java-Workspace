package com.cg.lab7q4.bean;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class SquareMain {
	public static HashMap<Integer,Integer> getSquares(int[] a) {
	    HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
	 
	    for (int n: a) {
	      map.put( n, n*n);
	    }
	    return map;
	  }
	 
	  public static void main(String[] args) 
	  {
		  Scanner s=new Scanner(System.in);
		  int n=s.nextInt();
		  int arr[]=new int[n];
		  for(int i=0;i<n;i++)
			  arr[i]=s.nextInt();
	    HashMap<Integer, Integer> map = getSquares(arr);
	    Iterator<Integer> it = map.keySet().iterator();
	    while(it.hasNext()){
	    Integer key = it.next();
	      System.out.println(key + " : " + map.get(key));
	    }
	    s.close();
	  }
	}