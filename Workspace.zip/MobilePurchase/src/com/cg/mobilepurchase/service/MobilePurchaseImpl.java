package com.cg.mobilepurchase.service;
import java.util.*;
import com.cg.mobilepurchase.bean.MobileDetails;
import com.cg.mobilepurchase.bean.PurchaseDetails;
import com.cg.mobilepurchase.repository.MobileRepository;

public class MobilePurchaseImpl implements MobileInterface{
	MobileRepository reposit=new MobileRepository();
   MobileDetails mobiledetail=new MobileDetails();
   Map<Integer,PurchaseDetails> purchase =new  HashMap<Integer,PurchaseDetails>();
  // Map<Integer,MobileDetails> mobile=new HashMap<Integer,MobileDetails>() ;
   Map<Integer,MobileDetails> mobile1=reposit.prepareMobileList();

  public  void insertDetails(int mobileid)
	{
	  if(mobile1.containsKey(mobileid))
	  {
		 MobileDetails m=mobile1.get(mobileid);
		 if(m.getMobile_quantity()>0)
		  {
		PurchaseDetails purchasedetail=new PurchaseDetails();
		Scanner scanner=new Scanner(System.in);
        purchasedetail.setCname(scanner.nextLine());
		purchasedetail.setMailId(scanner.nextLine());
		purchasedetail.setPurchasedate(scanner.nextLine());
		purchasedetail.setPhnNo(scanner.nextLine());
		purchasedetail.setPurchaseId(mobileid);
		
		purchase.put(mobileid, purchasedetail);
		Iterator<Integer> iterator=purchase.keySet().iterator();
		while(iterator.hasNext())
		{
			Integer key=iterator.next();
			System.out.println(key+":"+purchase.get(key));
		}
	  }
		  else
		  {
			  System.out.println("Not enough qunatity");
		  }
	 
		updateDetails(mobileid);
	//	scanner.close();
	}
	  else
		  System.out.println("Mobile id not exits Here!!");
	  }
  public void updateDetails(int mobileid)
  {
	 // MobileDetails m=mobile1.get(mobileid);
	// mobile1.put(mobileid, m.getMobile_quantity()-1);
	  
  }
	
	public  void viewMobileDetail()
	{
		Iterator<Integer> iterator=mobile1.keySet().iterator();
			while(iterator.hasNext())
			{
				Integer key=iterator.next();
				System.out.println(key+":"+mobile1.get(key));
			}
		
	}
	public  void deleteMobileDetail(int mobileid)
	{
		if(mobile1.containsKey(mobileid))
		{
			mobile1.remove(mobileid);
			System.out.println("Mobileid deleted");
		}
		else
			System.out.println("Mobile id not found");
	}
		
	public  void searchMobile(int low,int high)
	{
		Iterator<Integer> iterator1=mobile1.keySet().iterator();
		while(iterator1.hasNext())
		{
			Integer key1=iterator1.next();
			MobileDetails m=mobile1.get(key1);
			if(m.getMobilr_price()>=low &&m.getMobilr_price()<=high)
					{
				   System.out.println(key1+":"+mobile1.get(key1));
					}
		
		}
	
		
	}
	
	

}
