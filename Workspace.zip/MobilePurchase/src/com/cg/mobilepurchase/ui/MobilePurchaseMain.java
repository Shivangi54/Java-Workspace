package com.cg.mobilepurchase.ui;

import java.util.Scanner;

import com.cg.mobilepurchase.service.MobilePurchaseImpl;

public class MobilePurchaseMain {

	public static void main(String[] args) {
		int ch;
		MobilePurchaseImpl mobilepurch=new MobilePurchaseImpl();
		while(true)
		{
		
		System.out.println("Welcome to Mobile Purchase System");
		System.out.println("1.Insert the customer and purchase details into database.");
		System.out.println("2.View details of all mobiles available in the shop.");
		System.out.println("3.Delete a mobile details based on mobile id.");
		System.out.println("4.Search mobiles based on price range.");
		System.out.println("5.Exit.");
		System.out.println("Enter Your Choice");
		Scanner scanner=new Scanner(System.in);
		ch=scanner.nextInt();
		
		switch(ch)
		{
		case 1:System.out.println("Enter the mobileid you want to purchase");
		       int mobileid=scanner.nextInt();
			    mobilepurch.insertDetails(mobileid);
			//    mobilepurch.updateDetails(mobileid);
		break;
		case 2:
			mobilepurch.viewMobileDetail();
		break;
		case 3:System.out.println("Enter the mobileid you want to delete");
		       int mid=scanner.nextInt();
			mobilepurch.deleteMobileDetail(mid);
		break;
		case 4:System.out.println("Enter the range for mobile Purchase");
		      int low=scanner.nextInt();
		      int high=scanner.nextInt();
			mobilepurch.searchMobile(low,high);
		break;
		case 5:System.exit(0);
		break;
		}
		
		//scanner.close();
		}

}
}
