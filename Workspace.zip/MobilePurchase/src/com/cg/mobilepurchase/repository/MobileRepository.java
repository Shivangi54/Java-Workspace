package com.cg.mobilepurchase.repository;
import java.util.*;
import com.cg.mobilepurchase.bean.MobileDetails;
public class MobileRepository {
	
	  Map<Integer,MobileDetails> mobile=new HashMap<Integer,MobileDetails>();

	
	public Map<Integer, MobileDetails> prepareMobileList() {
		
		mobile.put(101,new MobileDetails("Redmi 5 Pro",13000,56));
		mobile.put(102,new MobileDetails("Redmi 6",12000,56));
		mobile.put(103,new MobileDetails("Samsung J Pro",10000,11));
		mobile.put(104,new MobileDetails("Panasonic",15000,30));
		mobile.put(105,new MobileDetails("Oppo A5",20000,66));
		mobile.put(106,new MobileDetails("Sony Xperia",30000,3));
		mobile.put(107,new MobileDetails("Vivo 12",12000,54));
		mobile.put(108,new MobileDetails("OnePlus 5",35000,43));
		mobile.put(109,new MobileDetails("Samsung E7",25000,20));
		mobile.put(110,new MobileDetails("Nokia Lumia",12000,56));
		return mobile;
	
	}
	
	public void updateDetails(int mobileid)
	{
		
	}

}
