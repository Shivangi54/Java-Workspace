package com.cg.lab4pr.bean;

public abstract class Account extends Person {
	private long AccNum;
	private double balance;
	private Person accHolder;
	public abstract void  withdraw(double a);
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public Account() {
		super();
		balance=500;
	}
	
	public long getAccNum() {
		return AccNum;
	}
	public void setAccNum(long accNum) {
		AccNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
      public void deposit(double a)
      {
    	balance=balance+a;
      }
     /* public void withdraw(double b)
      {
    	  if(balance<b)
    		  System.out.println("not sufficient");
    	  else
    		  balance=balance-b;
    	  
      }
     */
	@Override
	public String toString() {
		return "Account [AccNum=" + AccNum + ", balance=" + balance + ", accHolder=" + accHolder + "]";
	}
	
	
	}
	
	

      
	
	
     


