package com.cg.lab4pr.bean;

public class CurrentAccount extends Account {
	private float ovrdrftLimit;
	
	 public float getOvrdrftLimit() {
		return ovrdrftLimit;
	}

	public void setOvrdrftLimit(float ovrdrftLimit) {
		this.ovrdrftLimit = ovrdrftLimit;
	}
@Override
	public void withdraw(double amt)
     { 
   	  if(getBalance()<ovrdrftLimit)
   		System.out.println(printFalse());
   	  else
   		  System.out.println(printTrue());
   	  
     }
    public boolean printFalse()
    {
    	return false;
    }
    public boolean printTrue()
    {
    	return true;
    }
    

}
