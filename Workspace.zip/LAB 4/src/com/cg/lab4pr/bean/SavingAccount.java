package com.cg.lab4pr.bean;

public class SavingAccount extends Account{
          private final float minBalc=500;
          @Override
          public void withdraw(double b)
          {
        	  if(getBalance()<minBalc)
        		  System.out.println("not sufficient");
        	  else
        		  setBalance(getBalance()-b);
        	  
          }

}
