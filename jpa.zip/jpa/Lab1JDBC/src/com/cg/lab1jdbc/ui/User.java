package com.cg.lab1jdbc.ui;

import java.util.*;

import com.cg.lab1jdbc.service.*;

public class User {

	public static void main(String[] args) {
		
		
		ServiceImpl serviceImpl=new ServiceImpl();
		
		while(true) {
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter your choice\n1-Insert\n2-Display\n3-Delete\n4-Exit");
			int choice=scanner.nextInt();
			switch(choice) {
			case 1: serviceImpl.insert();
			        break;
			case 2: serviceImpl.display();
			        break;
			case 3: serviceImpl.delete();
			        break;
			case 4: System.exit(0);
			        break;
			}
			
		}
        
	}

}
