package com.cg.lab1jdbc.service;

import java.io.IOException;
import java.sql.*;
import java.util.*;

import com.cg.lab1jdbc.util.DBUtil;

public class ServiceImpl implements Service{
	    Connection conn=null;
	    Scanner scanner=new Scanner(System.in);
	    
        public void insert() {
        	String scheme=null;
        	System.out.println("Enter id");
        	int id=scanner.nextInt();
        	System.out.println("Enter Name");
        	scanner.nextLine();
        	String name=scanner.nextLine();
        	System.out.println("Enter designation");
        	String designation=scanner.nextLine();
        	System.out.println("Enter salary");
        	double sal=scanner.nextDouble();
        	if(sal>5000 && sal<20000 && designation.equals("System Associate"))
    			scheme="Scheme C";
    		else if(sal>=20000 && sal<40000 && designation.equals("Programmer"))
    			scheme="Scheme B";
    		else if(sal>=40000 && designation.equals("Manager"))
    			scheme="Scheme A";
    		else if(sal<5000 && designation.equals("Clerk"))
    			scheme="No Scheme";
        	if(!scheme.equals(null)) {
        	try {
				conn=DBUtil.getConn();
				String insertQuery="INSERT INTO Employee (emp_id,emp_name,emp_design,emp_sal,emp_insurance_scheme) VALUES(?,?,?,?,?) ";
				PreparedStatement pstmt=conn.prepareStatement(insertQuery);
				pstmt.setInt(1, id);
				pstmt.setString(2, name);
				pstmt.setString(3, designation);
				pstmt.setDouble(4, sal);
				pstmt.setString(5, scheme);
				pstmt.executeUpdate();
				System.out.println("Data is inserted!");
				
				
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
        	else
        		System.out.println("Invalid Input!");
        }
        public void display() {
        	try {
				conn=DBUtil.getConn();
				Statement stmt=conn.createStatement();
	        	ResultSet rs=stmt.executeQuery("SELECT * FROM Employee");
				System.out.println("ID \t\t NAME \t\t\t Designation\t\t\tSALARY \t\t Insurance Scheme");
				while(rs.next()) {
					System.out.println(rs.getInt("emp_id")+"\t\t"+rs.getString("emp_name")+"\t\t"+rs.getString("emp_design")+"\t\t"+rs.getFloat("emp_sal")+"\t\t"+rs.getString("emp_insurance_scheme"));
				}
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        }
        public void delete() {
            System.out.println("Enter employee id you want to delete");
            int eid=scanner.nextInt();
            try {
    			conn=DBUtil.getConn();
    			
    			String deleteQuery="DELETE FROM Employee WHERE emp_id =? ";
    			PreparedStatement pstmt=conn.prepareStatement(deleteQuery);
    			pstmt.setInt(1, eid);
    			pstmt.executeUpdate();
    			System.out.println("Data is deleted!");
    			
    			
    		} catch (SQLException | IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
        }
}
