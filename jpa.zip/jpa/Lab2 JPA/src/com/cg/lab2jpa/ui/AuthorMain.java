package com.cg.lab2jpa.ui;

import java.util.*;

import com.cg.lab2jpa.bean.Author;
import com.cg.lab2jpa.service.*;

public class AuthorMain {

	public static void main(String[] args) {
		AuthorService authorService=new AuthorServiceImpl();
		Author author=new Author();
        Scanner scanner=new Scanner(System.in);
        int choice,id;
        String fname,mname,lname,phone;
        while(true) {
        	System.out.println("Enter your choice\n1-Add Details\n2-Display Details\n3-Delete Details\n4-Update Details\n5-Exit");
        	choice=scanner.nextInt();
        	switch(choice) {
        	case 1: System.out.println("Enter the Author's First Name");
        	        scanner.nextLine();
        	        fname=scanner.nextLine();
        	        author.setFirstName(fname);
        	        
        	        System.out.println("Enter the Author's Middle Name");
        	        scanner.nextLine();
        	        mname=scanner.nextLine();
        	        author.setMiddleName(mname);
        	        System.out.println("Enter the Author's Last Name");
        	        scanner.nextLine();
        	        lname=scanner.nextLine();
        	        author.setLastName(lname);
        	        System.out.println("Enter Author's Phone No");
        	        scanner.nextLine();
        	        phone=scanner.nextLine();
        	        author.setPhoneNo(phone);
        	        Author author1=authorService.addAuthor(author);
        	        System.out.println(author1+" is inserted!");
        	        break;
        	case 2: System.out.println("Enter the Author Id you want to view");
        	        id=scanner.nextInt();
        	        author=authorService.displayAuthor(id);
        	        System.out.println(author);
        	        break;
        	case 3: System.out.println("Enter the Author Id you want to delete");
	                id=scanner.nextInt();
	                author=authorService.deleteAuthor(id);
	                System.out.println(author);
	                break;
        	case 4: System.out.println("Enter the id you want to update");
        	        id=scanner.nextInt();
        	        scanner.nextLine();
        	        System.out.println("Enter the updated author's first name");
        	        author.setFirstName(scanner.nextLine());
        	        System.out.println("Enter the updated author's middle name");
        	        author.setMiddleName(scanner.nextLine());
        	        System.out.println("Enter the updated author's last name");
        	        author.setLastName(scanner.nextLine());
        	        System.out.println("Enter the udpated author's phone no");
        	        author.setPhoneNo(scanner.nextLine());
        	        Author author2=authorService.updateAuthor(id, author.getFirstName(), author.getMiddleName(), author.getLastName(), author.getPhoneNo());
        	        System.out.println(author2+" is updated!");
        	        break;
        	case 5: System.exit(0);
        	}
        }
	}

}
