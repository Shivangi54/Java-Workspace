package com.cg.lab2jpa.dao;

import javax.persistence.*;
import com.cg.ems.util.JPAUtil;
import com.cg.lab2jpa.bean.Author;

public class AuthorDaoImpl implements AuthorDao{
    EntityManager em=null;
    EntityTransaction tran=null;
    public AuthorDaoImpl() {
    	em=JPAUtil.getEntityManager();
    	tran=em.getTransaction();
    }
	@Override
	public Author addAuthor(Author author) {
		tran.begin();
		em.persist(author);
		tran.commit();
		return author;
	}

	@Override
	public Author deleteAuthor(int authorId) {
		Author author=em.find(Author.class, authorId);
		tran.begin();
		em.remove(author);
		tran.commit();
		return author;
		
	}

	@Override
	public Author displayAuthor(int authorId) {
		Author author=em.find(Author.class, authorId);
		return author;
	}

	@Override
	public Author updateAuthor(int authorId, String newFirstName, String newMiddleName, String newLastName,
			String newPhoneNo) {
		Author author=em.find(Author.class, authorId);
		author.setFirstName(newFirstName);
		author.setMiddleName(newMiddleName);
		author.setLastName(newLastName);
		author.setPhoneNo(newPhoneNo);
		tran.begin();
		em.merge(author);
		tran.commit();
		return author;
	}

}
