package com.cg.lab2jpa.service;

import com.cg.lab2jpa.bean.Author;

public interface AuthorService {
	public Author addAuthor(Author author);
    public Author deleteAuthor(int authorId);
    public Author displayAuthor(int authorId);
    public Author updateAuthor(int authorId,String newFirstName,String newMiddleName,String newLastName,String newPhoneNo);
}
