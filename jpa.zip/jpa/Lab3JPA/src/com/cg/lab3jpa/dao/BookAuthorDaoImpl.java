package com.cg.lab3jpa.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import com.cg.lab3jpa.dto.Author;
import com.cg.lab3jpa.dto.Book;
import com.cg.lab3jpa.util.JPAUtil;

public class BookAuthorDaoImpl implements BookAuthorDao{
	EntityManager em=null;
    EntityTransaction entityTransaction=null;
    public BookAuthorDaoImpl() {
    	em=JPAUtil.getEntityManager();
    	entityTransaction=em.getTransaction();
    }
	@Override
	public ArrayList<Book> QueryAll() {
		
		TypedQuery tq=em.createQuery("SELECT books FROM Book books",Book.class);
		ArrayList<Book> bookSet=(ArrayList)tq.getResultList();
		return bookSet;
	}

	@Override
	public ArrayList<Book> QueryByAuthorName(String authName) {
		TypedQuery tq=em.createQuery("SELECT books from Book books, IN(books.authSet) a where a.name='"+authName+"'",Book.class);
		ArrayList<Book> book=(ArrayList)tq.getResultList();
		return book;
	}

	@Override
	public ArrayList<Book> QueryByRange(float lowRange, float highRange) {
		TypedQuery tq=em.createQuery("SELECT books from Book books where books.price between :lowRange AND :highRange",Book.class);
		tq.setParameter("lowRange", lowRange);
		tq.setParameter("highRange", highRange);
		ArrayList<Book> bookList=(ArrayList)tq.getResultList();
		return bookList;
	}

	@Override
	public ArrayList<Author> QueryByBookId(int bookId) {
		
		TypedQuery tq=em.createQuery("SELECT author from Author author, IN(author.bookSet) b where b.ISBN="+bookId,Author.class);
		ArrayList<Author> AuthList=(ArrayList)tq.getResultList();
		return AuthList;
	}

}
