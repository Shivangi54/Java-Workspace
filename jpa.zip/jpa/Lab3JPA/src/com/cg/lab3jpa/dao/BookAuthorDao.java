package com.cg.lab3jpa.dao;

import java.util.ArrayList;


import com.cg.lab3jpa.dto.Author;
import com.cg.lab3jpa.dto.Book;

public interface BookAuthorDao {
	public ArrayList<Book> QueryAll();
    public ArrayList<Book> QueryByAuthorName(String authName);
    public ArrayList<Book> QueryByRange(float lowRange,float highRange);
    public ArrayList<Author> QueryByBookId(int bookId);
}
