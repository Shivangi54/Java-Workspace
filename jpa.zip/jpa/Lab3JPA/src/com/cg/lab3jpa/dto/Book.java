package com.cg.lab3jpa.dto;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
@Entity
public class Book {
       @Id
       @Column(name="book_isbn", length=10)
       private int ISBN;
       @Column(name="book_title", length=30)
       private String title;
       @Column(name="book_price", length=10)
       private float price;
       @ManyToMany(mappedBy="bookSet")
	   private Set<Author> authSet=new HashSet<Author>();
       
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	public Book() {
		super();
	}
	public Set<Author> getAuthorSet() {
		return authSet;
	}
	public void setAuthorSet(Author author) {
		this.authSet.add(author);
	}
	
	public Book(int iSBN, String title, float price, Author author) {
		super();
		ISBN = iSBN;
		this.title = title;
		this.price = price;
		this.authSet.add(author);
		
	}
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price + ", authSet=" + authSet +  "]";
	}
	
       
}
