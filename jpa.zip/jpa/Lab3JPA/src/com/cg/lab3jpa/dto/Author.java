package com.cg.lab3jpa.dto;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity

public class Author {
	   @Id
	   @Column(name="author_name", length=30)
       private String name;
	   @Column(name="author_id", length=10)
       private int id;
	   @ManyToOne
	   @JoinColumn(name="book_id")
	   private Book book;
	   @ManyToMany(cascade=CascadeType.ALL)
	   @JoinTable(name="book_author", joinColumns= {@JoinColumn(name="author_name")},inverseJoinColumns= {@JoinColumn(name="book_isbn")})
       private Set<Book> bookSet=new HashSet<Book>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<Book> getBookSet() {
		return bookSet;
	}
	public void setBookSet(Book book) {
		this.bookSet.add(book);
	}
	public Author() {
		super();
	}
	
	public Author(int id, String name, Book book) {
		super();
		this.id = id;
		this.name = name;
		this.bookSet.add(book);
		
	}
	@Override
	public String toString() {
		return "Author [id=" + id + ", name=" + name + ", bookSet=" + bookSet +  "]";
	}
	
	   
}
