package com.cg.lab3jpa.ui;

import java.util.*;

import javax.persistence.*;


import com.cg.lab3jpa.dto.*;
import com.cg.lab3jpa.service.*;
import com.cg.lab3jpa.util.JPAUtil;

public class BookAuthorMain {

	public static void main(String[] args) {
		EntityManager em=JPAUtil.getEntityManager();
        EntityTransaction et=em.getTransaction();
        BookAuthorService bookAuthorService=new BookAuthorServiceImpl();
        ArrayList<Book> book=new ArrayList<Book>();
        ArrayList<Author> author=new ArrayList<Author>();
        int choice;
        Scanner scanner=new Scanner(System.in);
        Author a1=new Author();
        Author a2=new Author();
        Author a3=new Author();
        Author a4=new Author();
        Author a5=new Author();
        
        Book b1=new Book();
        Book b2=new Book();
        Book b3=new Book();
        Book b4=new Book();
        a1.setId(111);
        a1.setName("Sona Charaipotra");
        
        a2.setId(222);
        a2.setName("Dhonielle Clayton");
        
        b1.setISBN(100);
        b1.setTitle("Tiny Pretty Things");
        b1.setPrice(800);
        
        a3.setId(333);
        a3.setName("Stephen King");
        
        a4.setId(444);
        a4.setName("Peter Straub");
        
        b2.setISBN(200);
        b2.setTitle("The Talisman");
        b2.setPrice(950);
       
        b3.setISBN(300);
        b3.setTitle("It");
        b3.setPrice(500);
        
        
        a5.setId(555);
        a5.setName("John Green");
        
        b4.setISBN(400);
        b4.setTitle("Fault In Our Stars");
        b4.setPrice(650); 
        
        
        a1.getBookSet().add(b1);
        
        a2.getBookSet().add(b1);
        
       b1.setAuthorSet(a1);
       b1.setAuthorSet(a2);
        b2.setAuthorSet(a3);
        b2.setAuthorSet(a4);
        a3.setBookSet(b2);;
        
        a4.setBookSet(b2);;
       
        a3.setBookSet(b3);;
       
        b3.setAuthorSet(a3);
        a5.setBookSet(b4);;
       
      
        b4.setAuthorSet(a5);
        
        et.begin();
        em.persist(a1);
        em.persist(a2);
        em.persist(a3);
        em.persist(a4);
        em.persist(a5);
        em.persist(b1);
        em.persist(b2);
        em.persist(b3);
        em.persist(b4);
        et.commit();
        while(true) {
        	System.out.println("Enter your choice\n1-Query all books in database\n2-Query all books written by given author name\n3-List all books in given price range\n4-List the author name for given book id\n5-Exit");
        	choice=scanner.nextInt();
        	switch(choice) {
        	case 1: book=bookAuthorService.QueryAll();
        	        for(Book b:book) {
        	        	System.out.println(b.getISBN()+"\t"+b.getTitle()+"\t"+b.getPrice());
        	        }
        	        break;
        	case 2: System.out.println("Enter the author Name");
        	        scanner.nextLine();
        	        String name=scanner.nextLine();
        	        book=bookAuthorService.QueryByAuthorName(name);
        	        for(Book b:book) {
        	        	System.out.println(b.getISBN()+"\t"+b.getTitle()+"\t"+b.getPrice());
        	        }
        	        break;
        	case 3: System.out.println("Enter the range of books");
        	        float l=scanner.nextFloat();
        	        float h=scanner.nextFloat();
        	        book=bookAuthorService.QueryByRange(l, h);
        	        for(Book b:book) {
        	        	System.out.println(b.getISBN()+"\t"+b.getTitle()+"\t"+b.getPrice());
        	        }
        	        break;
        	case 4: System.out.println("Enter the book id");
        	        int id=scanner.nextInt();
        	        author=bookAuthorService.QueryByBookId(id);
        	        for(Author a:author)
        	        	System.out.println(a.getId()+"\t"+a.getName());
        	        break;
        	case 5: System.exit(0);
        	}
        	
        }
        
       
	}

}
