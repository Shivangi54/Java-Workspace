package com.cg.lab3jpa.service;

import java.util.ArrayList;


import com.cg.lab3jpa.dao.*;
import com.cg.lab3jpa.dto.Author;
import com.cg.lab3jpa.dto.Book;

public class BookAuthorServiceImpl implements BookAuthorService{
	BookAuthorDao bookAuthorDao=null;
    public BookAuthorServiceImpl() {
    	bookAuthorDao=new BookAuthorDaoImpl();
    }
	@Override
	public ArrayList<Book> QueryAll() {
		
		return bookAuthorDao.QueryAll();
	}

	@Override
	public ArrayList<Book> QueryByAuthorName(String authName) {
		
		return bookAuthorDao.QueryByAuthorName(authName);
	}

	@Override
	public ArrayList<Book> QueryByRange(float lowRange, float highRange) {
		
		return bookAuthorDao.QueryByRange(lowRange, highRange);
	}

	@Override
	public ArrayList<Author> QueryByBookId(int bookId) {
		
		return bookAuthorDao.QueryByBookId(bookId);
	}

}
