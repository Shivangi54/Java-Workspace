package com.cg.lab3jpa.service;

import java.util.ArrayList;

import com.cg.lab3jpa.dto.*;

public interface BookAuthorService {
       public ArrayList<Book> QueryAll();
       public ArrayList<Book> QueryByAuthorName(String authName);
       public ArrayList<Book> QueryByRange(float lowRange,float highRange);
       public ArrayList<Author> QueryByBookId(int bookId);
}
