package com.cg.mra.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	 private static Account acc=new Account();
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		AccountService service  = new AccountServiceImpl();;
        while(true) {
        //		To display the menu to user
			System.out.println("Enter your choice");
			System.out.println("1. Account Balance Enquiry");
			System.out.println("2. Recharge Account");
			System.out.println("3. Exit");

			int choice = scanner.nextInt();

			switch (choice) {
			case 1:
				//Case1: To take inputs from the user and also to validate the user inputs
				
				
				System.out.println("Enter Mobile No: ");
				String mobileNumber = scanner.next();
				if(!(validateMobNo(mobileNumber)))
					 System.out.println("Please Enter a Valid Mobile Number");
				  
				else
				{
					
			    
				try {
					acc = service.getAccountDetails(mobileNumber);
					System.out.println("Your Current Balance is Rs. "+acc.getAccountBalance());
				} catch (MobileRechargeException e) {
					
					System.out.println(e.getMessage());
				}
				
			
				}
				break;

			case 2:
				//case2: is to take input from user and recharge the account and display the current balance
				
				
				System.out.println("Enter MobileNo: ");
				String mobileNum = scanner.next();
				if(!(validateMobNo(mobileNum)))
					System.out.println("Inavlid Mobile Number...");
				else {
				System.out.println("Enter Recharge Amount: ");
				double rechargeAmount = scanner.nextDouble();
				if(!(validateAmount( rechargeAmount)))
					System.out.println("Invalid amount entered...");
				else {
				try {
				    acc=service.getAccountDetails(mobileNum);
					service.rechargeAccount(mobileNum,  rechargeAmount);
					System.out.println("Your Account Recharged Successfully");
					System.out.println("Hello "+acc.getCustomerName()+", Available Balance is "+acc.getAccountBalance());
				} catch (MobileRechargeException e) {
					
					System.out.println(e.getMessage());
				}
				}
				}
				break;

		
			case 3:
				System.exit(0);
			default:System.out.println("Wrong choice entered!!!");
			}

		}
	}

	private static boolean validateAmount(double rechargeAmount) {
		Pattern pattern = Pattern.compile("[1-9][0-9.]{0,15}");
		Matcher matcher = pattern.matcher(String.valueOf(rechargeAmount));
		return matcher.matches();
	}

	private static boolean validateMobNo(String mobileNumber) {
		Pattern pattern = Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher = pattern.matcher(mobileNumber);
		return matcher.matches();
		
	}

}
