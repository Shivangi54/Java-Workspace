package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileRechargeException;

public class AccountDaoImpl implements AccountDao {
	static Map<String, Account> accountEntry=new HashMap<String,Account>();
	
 public AccountDaoImpl() {
		
		accountEntry.put("9010210131", new Account("9010210131","Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("9823920123","Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("9823920123","Prepaid", "Vikas", 631));
		accountEntry.put("9010210132", new Account("9010210132","Prepaid", "Anju", 521));
		accountEntry.put("9010210133", new Account("9010210133","Prepaid", "Tushar", 632));
		
	}

	@Override
	public Account getAccountDetails(String mobileNo)  {
	 
		if(accountEntry.containsKey(mobileNo))
		{
			return accountEntry.get(mobileNo);
		}
		else
		{
			return null;
		}
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount)  {
		
		Account account;
      double balance;
		if(accountEntry.containsKey(mobileNo))
		{
			account=accountEntry.get(mobileNo);
			balance=account.getAccountBalance()+rechargeAmount;
			account.setAccountBalance(balance);
			accountEntry.put(mobileNo, account);
			return balance;
		}
		else
		{
			return 0;
		}
		
	}

}
