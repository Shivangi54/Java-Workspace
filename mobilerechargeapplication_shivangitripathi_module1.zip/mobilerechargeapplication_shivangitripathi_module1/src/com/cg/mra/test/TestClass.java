package com.cg.mra.test;



import org.junit.Before;
import org.junit.Test;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class TestClass {
	
//	Testing all the possible cases for the method rechargeAmount
  
	AccountService  accountservice;
	@Before
	public void setUp() throws Exception {
		
		accountservice = new AccountServiceImpl();
		
	}
	

	//When Wrong mobile Number is entered then mobile recharge exception is thrown
	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethod() throws MobileRechargeException{
		accountservice.rechargeAccount("7895167416", 123);
		
	}
	//When wrong recharge amount is entered mobile recharge exception is thrown
	@Test (expected = MobileRechargeException.class)
	public void TestOnBalanceRechargeAccountMethod() throws MobileRechargeException{
		accountservice.rechargeAccount("9010210131", -12);
		
	}
	
	
	
	

}
