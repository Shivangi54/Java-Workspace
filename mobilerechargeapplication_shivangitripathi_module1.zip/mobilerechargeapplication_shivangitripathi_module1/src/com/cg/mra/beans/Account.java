package com.cg.mra.beans;


public class Account {
	private String mobilNo;
	private String accountType;
	private String customerName;
	private double accountBalance;
	



	public Account(String mobilNo, String accountType, String customerName, double accountBalance) {
		super();
		this.mobilNo = mobilNo;
		this.accountType = accountType;
		this.customerName = customerName;
		this.accountBalance = accountBalance;
	}

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public String getMobilNo() {
		return mobilNo;
	}

	public void setMobilNo(String mobilNo) {
		this.mobilNo = mobilNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	
	
} 
