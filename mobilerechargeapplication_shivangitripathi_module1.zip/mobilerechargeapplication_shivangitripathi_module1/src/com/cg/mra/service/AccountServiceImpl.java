package com.cg.mra.service;


import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileRechargeException;

public class AccountServiceImpl implements AccountService {
	
	AccountDao dao;
	//This constructor is used to create a link between service and DAO layer
	public AccountServiceImpl() {
		
		dao = new AccountDaoImpl();
	}

//	This method is used to get the account details of the given mobile number
	@Override
	public Account getAccountDetails(String mobileNo) throws MobileRechargeException {
	     
		Account account=dao.getAccountDetails(mobileNo);
		if(account==null)
		{
			throw new MobileRechargeException("ERROR:Given Account Id Does Not Exist");
		}
		else
			return account;
			
	}

//	This method is used to recharge the account of the given mobile number
	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws MobileRechargeException {
		Account account=dao.getAccountDetails(mobileNo);
		if(account==null)
		{
			throw new MobileRechargeException("ERROR:Cannot Recharge Account as Given Mobile No Does Not Exists");
		}
		else{
			
			double balance;
			if(rechargeAmount<0)
				throw new MobileRechargeException("ERROR:Cannot Recharge Account as Given Mobile No Does Not Exists");
		
			else
			{
				balance=dao.rechargeAccount(mobileNo, rechargeAmount);
				return balance;
			}
				
		}
			
		
	}


	

}
