package com.cg.lab11question4.com;

@FunctionalInterface
public interface IProgram4 {
	public Simple methodDemo();


}