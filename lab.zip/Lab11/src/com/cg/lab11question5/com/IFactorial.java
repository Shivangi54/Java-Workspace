package com.cg.lab11question5.com;

public interface IFactorial {
	  public void fact();
	}