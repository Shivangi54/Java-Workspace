package com.cg.lab11pract.question1;
public @interface FunctionalInterface {

}

