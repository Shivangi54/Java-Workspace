package com.cg.lab11practques3.com;
public interface ILoginOperation {
boolean login(String uname, String pass);

}


