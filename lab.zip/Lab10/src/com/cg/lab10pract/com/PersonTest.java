package com.cg.lab10pract.com;
import com.cg.lab10pract.*;
import static org.junit.Assert.*;

import org.junit.Test;

public class PersonTest extends Person {
    // Person p;
	@Test
 public void testGetFirstName() {
		Person p = new Person();
		p.setFirstName("keerthana");
		assertEquals("keerthana",p.getFirstName());
				
	}
 public void testGetLastName() {
	 Person p = new Person();
	 p.setLastName("karnati");
	 assertEquals("karnati",p.getLastName());
	 
 }
public void testGetGender() {
	Person p = new Person();
	p.setGender("f");
	assertEquals("f",p.getGender());
}
}
